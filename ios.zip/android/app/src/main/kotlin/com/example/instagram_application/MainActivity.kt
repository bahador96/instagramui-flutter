package com.example.instagram_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
